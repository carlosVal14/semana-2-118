<template>
  <footer class="page-footer bg-secondary text-white pt-4">
    <!-- Footer Text -->
    <div class="container-fluid text-center text-md-left">
      <!-- Grid row -->
      <div class="row">
        <!-- Grid column -->
        <div class="col-md-6 mt-md-0 mt-3">
          <!-- Content -->
         <h5 class="text-uppercase font-weight-bold">Descripción</h5>
                <p>La actual página se basa en el acompañamiento y asesoramiento en servicios de mantenimiento, desarollo y automatización. </p>
                <p><a href="https://github.com/nlmedinap/semana-2-118.git">Enlace a GitHub</a></p>
                <p>Gracias por visitar nuestra página, para mayor información escribir al correo electrónico.</p>

            </div>
        <!-- Grid column -->

        <hr class="clearfix w-100 d-md-none pb-3" />

        <!-- Grid column -->
        <div class="col-md-6 mb-md-0 mb-3">
          <!-- Content -->
         <h5 class="text-uppercase font-weight-bold">Contacto</h5>
               <p> - Carlos Valencia: - valenciacarloslfgq20@gmail.com </p><p> - Pablo Pelaez: - onepelaez.sar@gmail.com </p>
                <p> - Lucia Medina: -nlmedinap@unal.edu.co </p><p>- Luz Orjuela: - luz.orjuela.rojas@gmail.com</p>

            </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
    <!-- Footer Text -->

    <!-- Copyright -->
    <div class="footer-copyright text-center py-1 bg-dark">
      © 2020 Copyright: DAD
    </div>
    <!-- Copyright -->
  </footer>
</template>
<script>
export default {
  name: "PageFooter",
};
</script>
<style scoped>
</style>